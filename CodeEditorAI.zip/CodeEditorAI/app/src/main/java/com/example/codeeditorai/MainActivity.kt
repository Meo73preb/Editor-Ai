package com.example.codeeditorai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.example.codeeditorai.ui.MainScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val darkColorScheme = darkColorScheme(
                primary = Color(0xFF667eea),
                secondary = Color(0xFF764ba2),
                tertiary = Color(0xFFf093fb),
                background = Color(0xFF1E1E1E),
                surface = Color(0xFF2D2D2D),
                onBackground = Color.White,
                onSurface = Color.White
            )

            MaterialTheme(
                colorScheme = darkColorScheme
            ) {
                MainScreen()
            }
        }
    }
}
