package com.example.codeeditorai.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

object SyntaxHighlighter {

    private val keywordColor = Color(0xFF9CDCFE)
    private val stringColor = Color(0xFFCE9178)
    private val commentColor = Color(0xFF6A9955)
    private val numberColor = Color(0xFFB5CEA8)
    private val operatorColor = Color(0xFFD4D4D4)
    private val functionColor = Color(0xFFDCDCAA)

    private val pythonKeywords = setOf(
        "def", "class", "if", "else", "elif", "for", "while", "import", "from",
        "return", "yield", "pass", "break", "continue", "try", "except", "finally",
        "with", "as", "lambda", "and", "or", "not", "is", "in", "True", "False",
        "None", "self", "async", "await"
    )

    private val jsKeywords = setOf(
        "function", "const", "let", "var", "if", "else", "for", "while", "do",
        "switch", "case", "break", "return", "import", "export", "from", "class",
        "extends", "static", "async", "await", "true", "false", "null", "undefined",
        "new", "this", "super", "try", "catch", "finally", "throw"
    )

    private val javaKeywords = setOf(
        "public", "private", "protected", "static", "final", "class", "interface",
        "extends", "implements", "new", "return", "if", "else", "for", "while",
        "do", "switch", "case", "break", "default", "try", "catch", "finally",
        "throw", "throws", "import", "package", "void", "int", "String", "boolean",
        "double", "float", "long", "short", "byte", "char"
    )

    fun highlight(code: String, language: String): AnnotatedString {
        return buildAnnotatedString {
            val keywords = when (language.lowercase()) {
                "python" -> pythonKeywords
                "javascript", "js" -> jsKeywords
                "java" -> javaKeywords
                else -> emptySet()
            }

            var i = 0
            while (i < code.length) {
                when {
                    // Handle strings
                    code[i] == '"' || code[i] == '\'' || code[i] == '`' -> {
                        val quoteChar = code[i]
                        val start = i
                        i++
                        while (i < code.length && code[i] != quoteChar) {
                            if (code[i] == '\\' && i + 1 < code.length) i++
                            i++
                        }
                        if (i < code.length) i++
                        pushStyle(SpanStyle(color = stringColor))
                        append(code.substring(start, i))
                        pop()
                    }

                    // Handle comments
                    i + 1 < code.length && code[i] == '/' && code[i + 1] == '/' -> {
                        val start = i
                        while (i < code.length && code[i] != '\n') i++
                        pushStyle(SpanStyle(color = commentColor))
                        append(code.substring(start, i))
                        pop()
                    }

                    i + 1 < code.length && code[i] == '#' -> {
                        val start = i
                        while (i < code.length && code[i] != '\n') i++
                        pushStyle(SpanStyle(color = commentColor))
                        append(code.substring(start, i))
                        pop()
                    }

                    // Handle numbers
                    code[i].isDigit() -> {
                        val start = i
                        while (i < code.length && (code[i].isDigit() || code[i] == '.')) i++
                        pushStyle(SpanStyle(color = numberColor))
                        append(code.substring(start, i))
                        pop()
                    }

                    // Handle identifiers and keywords
                    code[i].isLetter() || code[i] == '_' -> {
                        val start = i
                        while (i < code.length && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                        val word = code.substring(start, i)
                        when {
                            word in keywords -> {
                                pushStyle(SpanStyle(color = keywordColor, fontWeight = FontWeight.Bold))
                                append(word)
                                pop()
                            }
                            i < code.length && code[i] == '(' -> {
                                pushStyle(SpanStyle(color = functionColor))
                                append(word)
                                pop()
                            }
                            else -> append(word)
                        }
                    }

                    // Handle operators
                    code[i] in "+-*/%=<>!&|^~(){}[],.;:" -> {
                        pushStyle(SpanStyle(color = operatorColor))
                        append(code[i])
                        pop()
                        i++
                    }

                    // Whitespace and other chars
                    else -> {
                        append(code[i])
                        i++
                    }
                }
            }
        }
    }

    fun getLineNumbers(code: String): String {
        return code.lines().indices.joinToString("\n") { (it + 1).toString() }
    }
}
