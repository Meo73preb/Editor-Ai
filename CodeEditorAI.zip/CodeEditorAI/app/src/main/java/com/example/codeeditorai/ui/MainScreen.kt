package com.example.codeeditorai.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.codeeditorai.data.Language

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val viewModel: MainViewModel = remember {
        MainViewModel(context)
    }
    val appState by viewModel.appState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(viewModel, appState) },
        bottomBar = { BottomNavBar(viewModel, appState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF1E1E1E))
        ) {
            when (appState.selectedTab) {
                0 -> EditorTab(viewModel, appState)
                1 -> TerminalTab(viewModel, appState)
                2 -> AITab(viewModel, appState)
                3 -> HTMLPreviewTab(viewModel, appState)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBar(viewModel: MainViewModel, appState: AppState) {
    TopAppBar(
        title = {
            Column {
                Text(
                    "Code Editor AI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                if (appState.currentFile != null) {
                    Text(
                        appState.currentFile.name,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = { viewModel.saveCurrentFile() }) {
                Icon(Icons.Default.Save, "Save", tint = Color.White)
            }
            IconButton(onClick = { viewModel.runFile() }) {
                Icon(Icons.Default.PlayArrow, "Run", tint = Color.White)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(0xFF2D2D2D)
        )
    )
}

@Composable
fun BottomNavBar(viewModel: MainViewModel, appState: AppState) {
    NavigationBar(
        containerColor = Color(0xFF2D2D2D),
        contentColor = Color.White
    ) {
        NavigationBarItem(
            icon = { Icon(Icons.Default.Edit, null) },
            label = { Text("Editor") },
            selected = appState.selectedTab == 0,
            onClick = { viewModel.selectTab(0) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = Color(0xFF667eea),
                selectedIconColor = Color.White,
                unselectedIconColor = Color.Gray
            )
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Terminal, null) },
            label = { Text("Terminal") },
            selected = appState.selectedTab == 1,
            onClick = { viewModel.selectTab(1) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = Color(0xFF667eea),
                selectedIconColor = Color.White,
                unselectedIconColor = Color.Gray
            )
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Lightbulb, null) },
            label = { Text("AI") },
            selected = appState.selectedTab == 2,
            onClick = { viewModel.selectTab(2) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = Color(0xFF667eea),
                selectedIconColor = Color.White,
                unselectedIconColor = Color.Gray
            )
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Web, null) },
            label = { Text("Preview") },
            selected = appState.selectedTab == 3,
            onClick = { viewModel.selectTab(3) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = Color(0xFF667eea),
                selectedIconColor = Color.White,
                unselectedIconColor = Color.Gray
            )
        )
    }
}

@Composable
fun EditorTab(viewModel: MainViewModel, appState: AppState) {
    Row(modifier = Modifier.fillMaxSize()) {
        // File Browser
        FileExplorerPanel(
            modifier = Modifier
                .width(200.dp)
                .fillMaxHeight()
                .background(Color(0xFF252525)),
            viewModel = viewModel,
            appState = appState
        )

        Divider(
            color = Color(0xFF3D3D3D),
            modifier = Modifier
                .fillMaxHeight()
                .width(1.dp)
        )

        // Code Editor
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            if (appState.currentFile != null) {
                EditorPanel(viewModel, appState)
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E1E1E)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Note,
                            null,
                            modifier = Modifier.size(64.dp),
                            tint = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No file selected", color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                var showDialog by mutableStateOf(true)
                                if (showDialog) {
                                    // Show create file dialog
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF667eea)
                            )
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Create New File")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FileExplorerPanel(
    modifier: Modifier,
    viewModel: MainViewModel,
    appState: AppState
) {
    Column(modifier = modifier) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Files", color = Color.White, fontWeight = FontWeight.Bold)
            IconButton(onClick = { viewModel.loadFiles() }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Refresh, null, tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
        }

        Divider(color = Color(0xFF3D3D3D))

        // Files List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(appState.files) { file ->
                FileItem(
                    file = file,
                    isSelected = appState.currentFile?.path == file.path,
                    onSelect = { viewModel.openFile(file.path) },
                    onDelete = { viewModel.deleteFile(file.path) }
                )
            }
        }

        Divider(color = Color(0xFF3D3D3D))

        // Add File Button
        Button(
            onClick = { /* Show create file dialog */ },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF667eea))
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(modifier = Modifier.width(4.dp))
            Text("New File", fontSize = 12.sp)
        }
    }
}

@Composable
fun FileItem(
    file: com.example.codeeditorai.data.CodeFile,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) Color(0xFF3D3D3D) else Color.Transparent)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF2D2D2D))
                .padding(8.dp)
                .then(Modifier.noRippleClickable { onSelect }),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Description,
                null,
                tint = Color(0xFF667eea),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                file.name,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1
            )
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Delete, null, tint = Color.Red, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
fun EditorPanel(viewModel: MainViewModel, appState: AppState) {
    val currentFile = appState.currentFile ?: return
    var content by remember { mutableStateOf(currentFile.content) }

    LaunchedEffect(currentFile.path) {
        content = currentFile.content
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Code Editor Input
        BasicTextField(
            value = content,
            onValueChange = {
                content = it
                viewModel.updateFileContent(it)
            },
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF1E1E1E))
                .padding(12.dp),
            textStyle = androidx.compose.ui.text.TextStyle(
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        )

        // Status Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2D2D2D))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "${currentFile.language} | Lines: ${content.lines().size}",
                color = Color.Gray,
                fontSize = 10.sp
            )
            Text(
                if (currentFile.isModified) "● Modified" else "✓ Saved",
                color = if (currentFile.isModified) Color.Yellow else Color.Green,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun TerminalTab(viewModel: MainViewModel, appState: AppState) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Terminal Output
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF000000))
                .padding(12.dp)
        ) {
            items(appState.terminalHistory) { output ->
                TerminalOutputItem(output)
            }
        }

        Divider(color = Color(0xFF3D3D3D))

        // Terminal Input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E1E1E))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            var command by remember { mutableStateOf("") }

            Text("$ ", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
            BasicTextField(
                value = command,
                onValueChange = { command = it },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            )
            IconButton(
                onClick = {
                    if (command.isNotEmpty()) {
                        viewModel.executeCommand(command)
                        command = ""
                    }
                }
            ) {
                Icon(Icons.Default.Send, null, tint = Color(0xFF667eea))
            }
        }

        // Action Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2D2D2D))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { viewModel.runFile() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF667eea))
            ) {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Run File", fontSize = 11.sp)
            }

            Button(
                onClick = { viewModel.clearTerminal() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF444444))
            ) {
                Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clear", fontSize = 11.sp)
            }

            Button(
                onClick = { viewModel.openTermux() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF666666))
            ) {
                Icon(Icons.Default.Terminal, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Open Termux", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun TerminalOutputItem(output: com.example.codeeditorai.data.TerminalOutput) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            "$ ${output.command}",
            color = Color(0xFF00FF00),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
        if (output.output.isNotEmpty()) {
            Text(
                output.output,
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(start = 16.dp)
            )
        }
        if (output.error.isNotEmpty()) {
            Text(
                output.error,
                color = Color.Red,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(start = 16.dp)
            )
        }
    }
}

@Composable
fun AITab(viewModel: MainViewModel, appState: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .verticalScroll(rememberScrollState())
    ) {
        // Token Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2D2D2D))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "🔑 API Configuration",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (appState.hasToken) {
                    Text(
                        "✅ Token configured",
                        color = Color(0xFF00FF00),
                        fontSize = 12.sp
                    )
                } else {
                    Text(
                        "⚠️ No token - Using offline mode",
                        color = Color(0xFFFFAA00),
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { /* Show token input dialog */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF667eea)
                    )
                ) {
                    Text(if (appState.hasToken) "Update Token" else "Add Claude Token")
                }
            }
        }

        // Suggestions Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2D2D2D))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "💡 Code Suggestions",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.getAISuggestion() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = appState.currentFile != null && !appState.isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF667eea),
                        disabledContainerColor = Color(0xFF444444)
                    )
                ) {
                    if (appState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("Get AI Suggestion")
                }

                if (appState.aiSuggestion != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF1E1E1E)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "Suggestion:",
                                color = Color(0xFF667eea),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                appState.aiSuggestion.suggestion,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(top = 8.dp)
                            )

                            if (appState.aiSuggestion.explanation.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "Explanation:",
                                    color = Color(0xFF667eea),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    appState.aiSuggestion.explanation,
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    viewModel.copyToClipboard(appState.aiSuggestion.suggestion)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF444444)
                                )
                            ) {
                                Icon(Icons.Default.FileCopy, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Info Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2D2D2D))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "ℹ️ About AI Features",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    if (appState.hasToken) {
                        "🚀 AI-powered suggestions using Claude API"
                    } else {
                        "📌 Using local suggestions. Add API token for AI features."
                    },
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun HTMLPreviewTab(viewModel: MainViewModel, appState: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Web,
            null,
            modifier = Modifier.size(64.dp),
            tint = Color.Gray
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            "HTML Preview",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            "Open in browser: http://localhost:2435",
            color = Color.Gray,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                // Open browser
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF667eea)
            )
        ) {
            Icon(Icons.Default.OpenInBrowser, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Open in Browser")
        }
    }
}

// Utility composable
@Composable
fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier {
    return this.then(
        Modifier.background(Color.Transparent)
    )
}
