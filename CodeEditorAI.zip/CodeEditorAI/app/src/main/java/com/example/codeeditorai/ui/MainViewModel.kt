package com.example.codeeditorai.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.codeeditorai.ai.AIService
import com.example.codeeditorai.data.AIRequest
import com.example.codeeditorai.data.AIResponse
import com.example.codeeditorai.data.CodeFile
import com.example.codeeditorai.data.Language
import com.example.codeeditorai.data.SettingsRepository
import com.example.codeeditorai.data.TerminalOutput
import com.example.codeeditorai.data.TokenRepository
import com.example.codeeditorai.file.FileManager
import com.example.codeeditorai.terminal.TerminalService
import com.example.codeeditorai.web.WebServerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AppState(
    val currentFile: CodeFile? = null,
    val files: List<CodeFile> = emptyList(),
    val terminalHistory: List<TerminalOutput> = emptyList(),
    val aiSuggestion: AIResponse? = null,
    val hasToken: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null,
    val selectedTab: Int = 0 // 0: Editor, 1: Terminal, 2: AI, 3: HTML Preview
)

class MainViewModel(private val context: Context) : ViewModel() {

    private val _appState = MutableStateFlow(AppState())
    val appState: StateFlow<AppState> = _appState.asStateFlow()

    private val tokenRepository = TokenRepository(context)
    private val settingsRepository = SettingsRepository(context)
    private val fileManager = FileManager(context)
    private val terminalService = TerminalService(context)
    private val webServerService = WebServerService(context)
    private var aiService: AIService? = null

    init {
        initializeApp()
    }

    private fun initializeApp() {
        viewModelScope.launch {
            // Check for token
            val claudeToken = tokenRepository.getToken("claude")
            val hasToken = !claudeToken.isNullOrEmpty()
            
            _appState.update { it.copy(hasToken = hasToken) }
            
            // Initialize AI Service
            aiService = AIService(claudeToken, "claude")
            
            // Start web server
            webServerService.start()
            
            // Load files
            loadFiles()
        }
    }

    fun createNewFile(name: String, language: Language) {
        viewModelScope.launch {
            val file = fileManager.createFile(name, language)
            _appState.update { it.copy(currentFile = file) }
            loadFiles()
        }
    }

    fun openFile(path: String) {
        viewModelScope.launch {
            val file = fileManager.openFile(path)
            if (file != null) {
                _appState.update { it.copy(currentFile = file) }
            }
        }
    }

    fun saveCurrentFile() {
        viewModelScope.launch {
            val currentFile = _appState.value.currentFile
            if (currentFile != null) {
                val success = fileManager.saveFile(currentFile)
                if (success) {
                    _appState.update { it.copy(error = null) }
                    loadFiles()
                } else {
                    _appState.update { it.copy(error = "Failed to save file") }
                }
            }
        }
    }

    fun updateFileContent(content: String) {
        val current = _appState.value.currentFile
        if (current != null) {
            _appState.update { 
                it.copy(
                    currentFile = current.copy(
                        content = content,
                        isModified = true
                    )
                )
            }
        }
    }

    fun deleteFile(path: String) {
        viewModelScope.launch {
            val success = fileManager.deleteFile(path)
            if (success) {
                if (_appState.value.currentFile?.path == path) {
                    _appState.update { it.copy(currentFile = null) }
                }
                loadFiles()
            }
        }
    }

    fun loadFiles() {
        viewModelScope.launch {
            val files = fileManager.getFiles()
            _appState.update { it.copy(files = files) }
        }
    }

    fun executeCommand(command: String) {
        viewModelScope.launch {
            _appState.update { it.copy(isLoading = true) }
            val output = terminalService.executeCommand(command)
            _appState.update { state ->
                state.copy(
                    terminalHistory = state.terminalHistory + output,
                    isLoading = false
                )
            }
        }
    }

    fun runFile() {
        viewModelScope.launch {
            val currentFile = _appState.value.currentFile
            if (currentFile != null) {
                saveCurrentFile()
                _appState.update { it.copy(isLoading = true) }
                
                val output = terminalService.executeFile(currentFile.path, currentFile.language)
                _appState.update { state ->
                    state.copy(
                        terminalHistory = state.terminalHistory + output,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun clearTerminal() {
        _appState.update { it.copy(terminalHistory = emptyList()) }
    }

    fun getAISuggestion() {
        viewModelScope.launch {
            val currentFile = _appState.value.currentFile
            if (currentFile != null && aiService != null) {
                _appState.update { it.copy(isLoading = true) }
                
                val suggestion = aiService!!.getCodeSuggestion(
                    AIRequest(
                        code = currentFile.content,
                        language = currentFile.language,
                        prompt = "Suggest improvements for this code"
                    )
                )
                
                _appState.update { state ->
                    state.copy(
                        aiSuggestion = suggestion,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun setToken(provider: String, token: String) {
        viewModelScope.launch {
            tokenRepository.saveToken(provider, token)
            _appState.update { it.copy(hasToken = true) }
            aiService = AIService(token, provider)
        }
    }

    fun removeToken(provider: String) {
        viewModelScope.launch {
            tokenRepository.deleteToken(provider)
            _appState.update { it.copy(hasToken = false) }
            aiService = AIService(null, "offline")
        }
    }

    fun selectTab(tabIndex: Int) {
        _appState.update { it.copy(selectedTab = tabIndex) }
    }

    fun openTermux() {
        terminalService.openTermux()
    }

    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("Code", text)
        clipboard.setPrimaryClip(clip)
    }

    override fun onCleared() {
        super.onCleared()
        webServerService.stop()
    }
}
