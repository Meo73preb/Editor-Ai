package com.example.codeeditorai.data

// AI Models
data class AIRequest(
    val code: String,
    val language: String,
    val prompt: String,
    val model: String = "claude-3-5-sonnet-20241022"
)

data class AIResponse(
    val suggestion: String,
    val explanation: String = "",
    val examples: List<String> = emptyList(),
    val hasToken: Boolean = false
)

data class TokenConfig(
    val provider: String, // "claude", "openai"
    val token: String,
    val isValid: Boolean = false
)

// Code File Models
data class CodeFile(
    val id: String = "",
    val name: String,
    val path: String,
    val content: String,
    val language: String,
    val lastModified: Long = System.currentTimeMillis(),
    val isModified: Boolean = false
)

data class TerminalOutput(
    val command: String,
    val output: String,
    val error: String = "",
    val exitCode: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

// App Settings
data class AppSettings(
    val theme: String = "dark",
    val fontSize: Int = 14,
    val autoSave: Boolean = true,
    val autoSaveInterval: Long = 5000, // ms
    val defaultLanguage: String = "python",
    val showLineNumbers: Boolean = true,
    val wordWrap: Boolean = true
)

// Enums
enum class Language(val displayName: String, val extension: String) {
    PYTHON("Python", ".py"),
    JAVASCRIPT("JavaScript", ".js"),
    JAVA("Java", ".java"),
    KOTLIN("Kotlin", ".kt"),
    HTML("HTML", ".html"),
    CSS("CSS", ".css"),
    BASH("Bash", ".sh"),
    JSON("JSON", ".json"),
    XML("XML", ".xml"),
    TEXT("Text", ".txt")
}

enum class AIProvider(val displayName: String) {
    CLAUDE("Claude"),
    OPENAI("OpenAI"),
    OFFLINE("Offline Mode")
}
