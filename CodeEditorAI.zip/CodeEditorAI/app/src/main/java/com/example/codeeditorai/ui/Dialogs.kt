package com.example.codeeditorai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.codeeditorai.data.Language

@Composable
fun NewFileDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, language: Language) -> Unit
) {
    var fileName by remember { mutableStateOf("") }
    var selectedLanguage by remember { mutableStateOf(Language.PYTHON) }

    Dialog(
        onDismissRequest = onDismiss,
        content = {
            Surface(
                modifier = Modifier
                    .width(400.dp)
                    .clip(RoundedCornerShape(12.dp)),
                color = Color(0xFF2D2D2D)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Create New File",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, null, tint = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // File Name Input
                    Text("File Name", color = Color.White, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    TextField(
                        value = fileName,
                        onValueChange = { fileName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF1E1E1E),
                            unfocusedContainerColor = Color(0xFF1E1E1E),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        placeholder = { Text("script.py", color = Color.Gray, fontSize = 12.sp) },
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Language Selection
                    Text("Language", color = Color.White, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LanguageDropdown(
                        selectedLanguage = selectedLanguage,
                        onSelect = { selectedLanguage = it }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF444444)
                            )
                        ) {
                            Text("Cancel", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                if (fileName.isNotEmpty()) {
                                    onCreate(fileName, selectedLanguage)
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            enabled = fileName.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF667eea),
                                disabledContainerColor = Color(0xFF444444)
                            )
                        ) {
                            Text("Create", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun LanguageDropdown(
    selectedLanguage: Language,
    onSelect: (Language) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Button(
            onClick = { expanded = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1E1E1E)
            )
        ) {
            Text(
                selectedLanguage.displayName,
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Start
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .background(Color(0xFF2D2D2D))
        ) {
            Language.values().forEach { lang ->
                DropdownMenuItem(
                    text = {
                        Text(
                            lang.displayName,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    },
                    onClick = {
                        onSelect(lang)
                        expanded = false
                    },
                    modifier = Modifier.background(Color(0xFF2D2D2D))
                )
            }
        }
    }
}

@Composable
fun TokenDialog(
    onDismiss: () -> Unit,
    onSave: (token: String) -> Unit,
    currentToken: String = ""
) {
    var token by remember { mutableStateOf(currentToken) }
    var showPassword by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        content = {
            Surface(
                modifier = Modifier
                    .width(420.dp)
                    .clip(RoundedCornerShape(12.dp)),
                color = Color(0xFF2D2D2D)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "🔑 API Token Configuration",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, null, tint = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Info
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF1E1E1E)
                        )
                    ) {
                        Text(
                            "Get your API token from: https://console.anthropic.com\n\nYour token will be encrypted and stored securely on your device.",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Token Input
                    Text("Claude API Token", color = Color.White, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    TextField(
                        value = token,
                        onValueChange = { token = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF1E1E1E),
                            unfocusedContainerColor = Color(0xFF1E1E1E),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        placeholder = {
                            Text("sk-ant-...", color = Color.Gray, fontSize = 11.sp)
                        },
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        trailingIcon = {
                            IconButton(
                                onClick = { showPassword = !showPassword },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    if (showPassword) Icons.Default.Close else Icons.Default.Add,
                                    null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Warning
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF3D2D1F)
                    ) {
                        Text(
                            "⚠️ Keep your token private. Never share it publicly.",
                            color = Color(0xFFFFAA00),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF444444)
                            )
                        ) {
                            Text("Cancel", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                if (token.isNotEmpty()) {
                                    onSave(token)
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            enabled = token.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF667eea),
                                disabledContainerColor = Color(0xFF444444)
                            )
                        ) {
                            Text("Save Token", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    confirmButtonText: String = "Yes",
    dismissButtonText: String = "No"
) {
    Dialog(
        onDismissRequest = onDismiss,
        content = {
            Surface(
                modifier = Modifier
                    .width(300.dp)
                    .clip(RoundedCornerShape(12.dp)),
                color = Color(0xFF2D2D2D)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        message,
                        color = Color.Gray,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF444444)
                            )
                        ) {
                            Text(dismissButtonText, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                onConfirm()
                                onDismiss()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDD5555)
                            )
                        ) {
                            Text(confirmButtonText, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    )
}
