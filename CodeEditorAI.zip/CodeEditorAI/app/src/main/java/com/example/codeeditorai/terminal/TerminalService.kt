package com.example.codeeditorai.terminal

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.codeeditorai.data.TerminalOutput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class TerminalService(private val context: Context) {

    suspend fun executeCommand(command: String): TerminalOutput = withContext(Dispatchers.IO) {
        return@withContext try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            
            // Set timeout
            val completed = process.waitFor(30, TimeUnit.SECONDS)
            
            val outputReader = BufferedReader(InputStreamReader(process.inputStream))
            val output = outputReader.readText()
            
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val error = errorReader.readText()
            
            val exitCode = if (completed) process.exitValue() else -1
            
            outputReader.close()
            errorReader.close()
            process.destroy()
            
            TerminalOutput(
                command = command,
                output = output,
                error = error,
                exitCode = exitCode
            )
        } catch (e: Exception) {
            Log.e("TerminalService", "Error executing command: ${e.message}")
            TerminalOutput(
                command = command,
                output = "",
                error = "Error: ${e.message}",
                exitCode = -1
            )
        }
    }

    suspend fun executeFile(filePath: String, language: String): TerminalOutput = withContext(Dispatchers.IO) {
        return@withContext when (language.lowercase()) {
            "python" -> executePython(filePath)
            "javascript" -> executeNode(filePath)
            "java" -> executeJava(filePath)
            "bash", "sh" -> executeBash(filePath)
            "html" -> executeHTML(filePath)
            else -> TerminalOutput(
                command = filePath,
                output = "",
                error = "Unsupported language: $language",
                exitCode = -1
            )
        }
    }

    private suspend fun executePython(filePath: String): TerminalOutput = withContext(Dispatchers.IO) {
        try {
            val command = "python $filePath"
            return@withContext executeCommand(command)
        } catch (e: Exception) {
            TerminalOutput(
                command = filePath,
                output = "",
                error = "Python not installed: ${e.message}",
                exitCode = -1
            )
        }
    }

    private suspend fun executeNode(filePath: String): TerminalOutput = withContext(Dispatchers.IO) {
        try {
            val command = "node $filePath"
            return@withContext executeCommand(command)
        } catch (e: Exception) {
            TerminalOutput(
                command = filePath,
                output = "",
                error = "Node.js not installed: ${e.message}",
                exitCode = -1
            )
        }
    }

    private suspend fun executeJava(filePath: String): TerminalOutput = withContext(Dispatchers.IO) {
        try {
            val fileName = File(filePath).nameWithoutExtension
            val directory = File(filePath).parent
            
            // Compile
            val compileCommand = "cd $directory && javac $(basename $filePath)"
            executeCommand(compileCommand)
            
            // Run
            val runCommand = "cd $directory && java $fileName"
            return@withContext executeCommand(runCommand)
        } catch (e: Exception) {
            TerminalOutput(
                command = filePath,
                output = "",
                error = "Java error: ${e.message}",
                exitCode = -1
            )
        }
    }

    private suspend fun executeBash(filePath: String): TerminalOutput = withContext(Dispatchers.IO) {
        try {
            val command = "bash $filePath"
            return@withContext executeCommand(command)
        } catch (e: Exception) {
            TerminalOutput(
                command = filePath,
                output = "",
                error = "Bash error: ${e.message}",
                exitCode = -1
            )
        }
    }

    private suspend fun executeHTML(filePath: String): TerminalOutput = withContext(Dispatchers.IO) {
        // HTML doesn't execute, just return the file path for preview
        TerminalOutput(
            command = filePath,
            output = "HTML file ready for preview. Open HTML Preview tab.",
            error = "",
            exitCode = 0
        )
    }

    fun openTermux() {
        try {
            val intent = Intent()
            intent.setClassName("com.termux", "com.termux.app.TermuxActivity")
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("TerminalService", "Termux not installed: ${e.message}")
        }
    }

    suspend fun installPackage(packageName: String): TerminalOutput = withContext(Dispatchers.IO) {
        try {
            val command = "apt-get update && apt-get install -y $packageName"
            return@withContext executeCommand(command)
        } catch (e: Exception) {
            TerminalOutput(
                command = packageName,
                output = "",
                error = "Install error: ${e.message}",
                exitCode = -1
            )
        }
    }

    suspend fun checkEnvironment(): Map<String, Boolean> = withContext(Dispatchers.IO) {
        return@withContext mapOf(
            "python" to checkCommand("which python3").exitCode == 0,
            "node" to checkCommand("which node").exitCode == 0,
            "java" to checkCommand("which java").exitCode == 0,
            "bash" to checkCommand("which bash").exitCode == 0
        )
    }

    private suspend fun checkCommand(command: String): TerminalOutput = withContext(Dispatchers.IO) {
        return@withContext executeCommand(command)
    }
}
