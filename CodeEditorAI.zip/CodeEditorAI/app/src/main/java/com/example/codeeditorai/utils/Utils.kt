package com.example.codeeditorai.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.codeeditorai.data.CodeFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object FileUtils {

    /**
     * Format file size in human readable format
     */
    fun formatFileSize(bytes: Long): String {
        return when {
            bytes <= 0 -> "0 B"
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
            else -> "${bytes / (1024 * 1024 * 1024)} GB"
        }
    }

    /**
     * Format timestamp to readable date
     */
    fun formatDate(timestamp: Long): String {
        val date = Date(timestamp)
        val format = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        return format.format(date)
    }

    /**
     * Get file extension
     */
    fun getFileExtension(fileName: String): String {
        return fileName.substringAfterLast(".", "")
    }

    /**
     * Check if file is binary
     */
    fun isBinaryFile(filePath: String): Boolean {
        val binaryExtensions = setOf(
            "jpg", "jpeg", "png", "gif", "bmp", "webp",
            "mp3", "mp4", "wav", "flac",
            "pdf", "zip", "rar", "7z", "jar", "apk"
        )
        val ext = getFileExtension(filePath).lowercase()
        return ext in binaryExtensions
    }

    /**
     * Count lines in code
     */
    fun countLines(code: String): Int = code.split("\n").size

    /**
     * Count characters in code
     */
    fun countCharacters(code: String): Int = code.length

    /**
     * Get word count
     */
    fun countWords(code: String): Int {
        return code.trim().split(Regex("\\s+")).size
    }

    /**
     * Calculate file checksum
     */
    fun calculateChecksum(code: String): String {
        return code.hashCode().toString()
    }
}

object CodeUtils {

    /**
     * Get indentation level
     */
    fun getIndentationLevel(line: String): Int {
        var count = 0
        for (char in line) {
            if (char == ' ') count++
            else if (char == '\t') count += 4
            else break
        }
        return count
    }

    /**
     * Auto-indent code
     */
    fun autoIndent(code: String, lineNumber: Int): String {
        val lines = code.split("\n")
        if (lineNumber <= 0 || lineNumber > lines.size) return code

        val previousLine = lines.getOrNull(lineNumber - 2) ?: ""
        val indent = getIndentationLevel(previousLine)

        // Check if previous line ends with colon or opening brace
        val needsExtraIndent = previousLine.trim().endsWith(":") || 
                               previousLine.trim().endsWith("{") ||
                               previousLine.trim().endsWith("(")

        val totalIndent = if (needsExtraIndent) indent + 4 else indent
        return " ".repeat(totalIndent)
    }

    /**
     * Detect code language from content
     */
    fun detectLanguage(code: String): String {
        return when {
            code.contains("def ") || code.contains("import ") || code.contains("from ") -> "python"
            code.contains("function ") || code.contains("const ") || code.contains("let ") -> "javascript"
            code.contains("public class ") || code.contains("import ") -> "java"
            code.contains("<!DOCTYPE") || code.contains("<html") -> "html"
            code.contains("#!/bin/bash") || code.contains("#!/bin/sh") -> "bash"
            else -> "text"
        }
    }

    /**
     * Get code snippet (first N lines)
     */
    fun getSnippet(code: String, lines: Int = 3): String {
        return code.split("\n").take(lines).joinToString("\n")
    }

    /**
     * Check if code is valid (basic check)
     */
    fun isValidCode(code: String, language: String): Boolean {
        return when (language.lowercase()) {
            "python" -> code.count { it == '(' } == code.count { it == ')' }
            "javascript" -> code.count { it == '{' } == code.count { it == '}' }
            "java" -> code.count { it == '{' } == code.count { it == '}' }
            else -> true
        }
    }

    /**
     * Find matching bracket
     */
    fun findMatchingBracket(code: String, position: Int, bracket: Char): Int {
        val closingBracket = when (bracket) {
            '(' -> ')'
            '{' -> '}'
            '[' -> ']'
            else -> return -1
        }

        var depth = 1
        for (i in position + 1 until code.length) {
            when (code[i]) {
                bracket -> depth++
                closingBracket -> {
                    depth--
                    if (depth == 0) return i
                }
            }
        }
        return -1
    }
}

object SystemUtils {

    /**
     * Open URL in browser
     */
    fun openUrl(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Share text
     */
    fun shareText(context: Context, text: String, subject: String = "Code") {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, "Share via"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Check if file exists
     */
    fun fileExists(path: String): Boolean {
        return File(path).exists()
    }

    /**
     * Get available storage space
     */
    fun getAvailableStorage(): Long {
        return try {
            File("/").freeSpace
        } catch (e: Exception) {
            0L
        }
    }
}

object ValidationUtils {

    /**
     * Validate file name
     */
    fun isValidFileName(name: String): Boolean {
        if (name.isBlank()) return false
        val invalidChars = setOf('<', '>', ':', '"', '/', '\\', '|', '?', '*')
        return !name.any { it in invalidChars }
    }

    /**
     * Validate API token format
     */
    fun isValidToken(token: String): Boolean {
        return token.isNotBlank() && token.length > 10
    }

    /**
     * Validate email (basic)
     */
    fun isValidEmail(email: String): Boolean {
        return email.contains("@") && email.contains(".")
    }

    /**
     * Validate port number
     */
    fun isValidPort(port: String): Boolean {
        return try {
            val p = port.toInt()
            p in 1..65535
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Check if path is safe (not escaping root)
     */
    fun isSafePath(path: String, baseDir: String): Boolean {
        return try {
            val basePath = File(baseDir).canonicalPath
            val fullPath = File(path).canonicalPath
            fullPath.startsWith(basePath)
        } catch (e: Exception) {
            false
        }
    }
}

object TextUtils {

    /**
     * Truncate text to max length with ellipsis
     */
    fun truncate(text: String, maxLength: Int): String {
        return if (text.length > maxLength) {
            text.take(maxLength - 3) + "..."
        } else {
            text
        }
    }

    /**
     * Convert bytes to readable format with syntax highlighting hint
     */
    fun getSyntaxHighlightHint(code: String): String {
        return when {
            code.contains("def ") -> "Looks like Python"
            code.contains("function ") -> "Looks like JavaScript"
            code.contains("public class") -> "Looks like Java"
            code.contains("<!DOCTYPE") -> "Looks like HTML"
            else -> "Unknown language"
        }
    }

    /**
     * Escape special characters for display
     */
    fun escapeSpecialChars(text: String): String {
        return text.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }

    /**
     * Unescape special characters
     */
    fun unescapeSpecialChars(text: String): String {
        return text.replace("\\\\", "\\")
            .replace("\\\"", "\"")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t")
    }
}

extension_functions.kt:

fun <T> List<T>.getOrNull(index: Int, default: T? = null): T? {
    return if (index in indices) get(index) else default
}

fun String.isValidFileName(): Boolean {
    return ValidationUtils.isValidFileName(this)
}

fun String.truncateTo(maxLength: Int): String {
    return TextUtils.truncate(this, maxLength)
}

fun File.sizeInMB(): Double {
    return length().toDouble() / (1024 * 1024)
}

fun CodeFile.getStats(): String {
    return "Lines: ${FileUtils.countLines(content)} | " +
           "Chars: ${FileUtils.countCharacters(content)} | " +
           "Size: ${FileUtils.formatFileSize(content.length.toLong())}"
}
