package com.example.codeeditorai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson

class TokenRepository(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedSharedPreferences = EncryptedSharedPreferences.create(
        context,
        "token_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val gson = Gson()

    fun saveToken(provider: String, token: String) {
        encryptedSharedPreferences.edit().apply {
            putString("${provider}_token", token)
            putBoolean("${provider}_has_token", true)
        }.apply()
    }

    fun getToken(provider: String): String? {
        return encryptedSharedPreferences.getString("${provider}_token", null)
    }

    fun hasToken(provider: String): Boolean {
        return encryptedSharedPreferences.getBoolean("${provider}_has_token", false)
    }

    fun deleteToken(provider: String) {
        encryptedSharedPreferences.edit().apply {
            remove("${provider}_token")
            putBoolean("${provider}_has_token", false)
        }.apply()
    }

    fun verifyToken(provider: String): Boolean {
        return getToken(provider) != null && !getToken(provider).isNullOrEmpty()
    }
}

class SettingsRepository(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveSettings(settings: AppSettings) {
        sharedPreferences.edit().apply {
            putString("app_settings_json", gson.toJson(settings))
        }.apply()
    }

    fun getSettings(): AppSettings {
        val json = sharedPreferences.getString("app_settings_json", null)
        return if (json != null) {
            gson.fromJson(json, AppSettings::class.java)
        } else {
            AppSettings()
        }
    }

    fun updateTheme(theme: String) {
        val current = getSettings()
        saveSettings(current.copy(theme = theme))
    }

    fun updateFontSize(size: Int) {
        val current = getSettings()
        saveSettings(current.copy(fontSize = size))
    }

    fun updateAutoSave(enabled: Boolean) {
        val current = getSettings()
        saveSettings(current.copy(autoSave = enabled))
    }
}
