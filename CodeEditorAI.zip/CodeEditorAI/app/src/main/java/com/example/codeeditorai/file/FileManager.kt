package com.example.codeeditorai.file

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.codeeditorai.data.CodeFile
import com.example.codeeditorai.data.Language
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class FileManager(private val context: Context) {

    private val baseDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CodeEditorAI")

    init {
        if (!baseDir.exists()) {
            baseDir.mkdirs()
        }
    }

    suspend fun createFile(name: String, language: Language): CodeFile = withContext(Dispatchers.IO) {
        val fileName = if (name.contains(".")) name else name + language.extension
        val file = File(baseDir, fileName)
        
        file.createNewFile()
        
        CodeFile(
            id = UUID.randomUUID().toString(),
            name = fileName,
            path = file.absolutePath,
            content = "",
            language = language.name,
            lastModified = System.currentTimeMillis()
        )
    }

    suspend fun openFile(path: String): CodeFile? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) return@withContext null
            
            val content = file.readText()
            val language = detectLanguage(file.extension)
            
            return@withContext CodeFile(
                id = UUID.randomUUID().toString(),
                name = file.name,
                path = file.absolutePath,
                content = content,
                language = language.name,
                lastModified = file.lastModified()
            )
        } catch (e: Exception) {
            Log.e("FileManager", "Error opening file: ${e.message}")
            null
        }
    }

    suspend fun saveFile(codeFile: CodeFile): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(codeFile.path)
            file.writeText(codeFile.content)
            return@withContext true
        } catch (e: Exception) {
            Log.e("FileManager", "Error saving file: ${e.message}")
            false
        }
    }

    suspend fun deleteFile(path: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            return@withContext file.delete()
        } catch (e: Exception) {
            Log.e("FileManager", "Error deleting file: ${e.message}")
            false
        }
    }

    suspend fun renameFile(oldPath: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val oldFile = File(oldPath)
            val newFile = File(oldFile.parent, newName)
            return@withContext oldFile.renameTo(newFile)
        } catch (e: Exception) {
            Log.e("FileManager", "Error renaming file: ${e.message}")
            false
        }
    }

    suspend fun getFiles(directory: String = baseDir.absolutePath): List<CodeFile> = withContext(Dispatchers.IO) {
        try {
            val dir = File(directory)
            if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()
            
            return@withContext dir.listFiles()?.map { file ->
                CodeFile(
                    id = UUID.randomUUID().toString(),
                    name = file.name,
                    path = file.absolutePath,
                    content = if (file.isFile) file.readText() else "",
                    language = if (file.isFile) detectLanguage(file.extension).name else "FOLDER",
                    lastModified = file.lastModified()
                )
            } ?: emptyList()
        } catch (e: Exception) {
            Log.e("FileManager", "Error listing files: ${e.message}")
            emptyList()
        }
    }

    suspend fun getFileContent(path: String): String? = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            return@withContext if (file.exists() && file.isFile) file.readText() else null
        } catch (e: Exception) {
            Log.e("FileManager", "Error reading file: ${e.message}")
            null
        }
    }

    suspend fun updateFileContent(path: String, content: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            file.writeText(content)
            return@withContext true
        } catch (e: Exception) {
            Log.e("FileManager", "Error updating file: ${e.message}")
            false
        }
    }

    suspend fun createFolder(name: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val folder = File(baseDir, name)
            return@withContext folder.mkdirs()
        } catch (e: Exception) {
            Log.e("FileManager", "Error creating folder: ${e.message}")
            false
        }
    }

    fun getBaseDirectory(): File = baseDir

    fun getTemporaryFile(name: String): File {
        val tempDir = File(baseDir, ".temp")
        if (!tempDir.exists()) {
            tempDir.mkdirs()
        }
        return File(tempDir, name)
    }

    private fun detectLanguage(extension: String): Language {
        return when (extension.lowercase()) {
            "py" -> Language.PYTHON
            "js" -> Language.JAVASCRIPT
            "java" -> Language.JAVA
            "kt" -> Language.KOTLIN
            "html", "htm" -> Language.HTML
            "css" -> Language.CSS
            "sh", "bash" -> Language.BASH
            "json" -> Language.JSON
            "xml" -> Language.XML
            else -> Language.TEXT
        }
    }

    suspend fun searchFiles(query: String, directory: String = baseDir.absolutePath): List<CodeFile> = withContext(Dispatchers.IO) {
        try {
            val files = mutableListOf<CodeFile>()
            val dir = File(directory)
            
            dir.walkTopDown().forEach { file ->
                if (file.name.contains(query, ignoreCase = true)) {
                    files.add(CodeFile(
                        id = UUID.randomUUID().toString(),
                        name = file.name,
                        path = file.absolutePath,
                        content = if (file.isFile) file.readText() else "",
                        language = if (file.isFile) detectLanguage(file.extension).name else "FOLDER",
                        lastModified = file.lastModified()
                    ))
                }
            }
            return@withContext files
        } catch (e: Exception) {
            Log.e("FileManager", "Error searching files: ${e.message}")
            emptyList()
        }
    }
}
