package com.example.codeeditorai.network

import android.util.Log
import com.google.gson.JsonObject
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class ApiResponse<T>(
    val data: T?,
    val error: String? = null,
    val statusCode: Int = 0,
    val isSuccess: Boolean = false
)

class ApiClient(
    private val baseUrl: String = "https://api.anthropic.com",
    private val timeout: Long = 30
) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(timeout, TimeUnit.SECONDS)
        .readTimeout(timeout, TimeUnit.SECONDS)
        .writeTimeout(timeout, TimeUnit.SECONDS)
        .addNetworkInterceptor(LoggingInterceptor())
        .build()

    suspend fun post(
        endpoint: String,
        headers: Map<String, String>,
        body: String
    ): ApiResponse<String> {
        return try {
            val url = "$baseUrl$endpoint"
            val requestBody = body.toRequestBody("application/json".toMediaType())
            
            val requestBuilder = Request.Builder()
                .url(url)
                .post(requestBody)
            
            headers.forEach { (key, value) ->
                requestBuilder.addHeader(key, value)
            }

            val request = requestBuilder.build()
            val response = httpClient.newCall(request).execute()

            val responseBody = response.body?.string() ?: ""
            
            ApiResponse(
                data = responseBody,
                error = if (response.isSuccessful) null else response.message,
                statusCode = response.code,
                isSuccess = response.isSuccessful
            )
        } catch (e: Exception) {
            Log.e("ApiClient", "Error in POST request: ${e.message}")
            ApiResponse(
                data = null,
                error = e.message,
                statusCode = -1,
                isSuccess = false
            )
        }
    }

    suspend fun get(
        endpoint: String,
        headers: Map<String, String> = emptyMap()
    ): ApiResponse<String> {
        return try {
            val url = "$baseUrl$endpoint"
            val requestBuilder = Request.Builder()
                .url(url)
                .get()

            headers.forEach { (key, value) ->
                requestBuilder.addHeader(key, value)
            }

            val request = requestBuilder.build()
            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            ApiResponse(
                data = responseBody,
                error = if (response.isSuccessful) null else response.message,
                statusCode = response.code,
                isSuccess = response.isSuccessful
            )
        } catch (e: Exception) {
            Log.e("ApiClient", "Error in GET request: ${e.message}")
            ApiResponse(
                data = null,
                error = e.message,
                statusCode = -1,
                isSuccess = false
            )
        }
    }

    fun shutdown() {
        httpClient.dispatcher.executorService.shutdown()
    }
}

class LoggingInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val startTime = System.currentTimeMillis()

        val response = try {
            chain.proceed(request)
        } catch (e: Exception) {
            Log.e("HttpLogging", "Request failed: ${e.message}")
            throw e
        }

        val duration = System.currentTimeMillis() - startTime
        
        Log.d("HttpLogging", """
            ${request.method} ${request.url}
            Status: ${response.code}
            Duration: ${duration}ms
        """.trimIndent())

        return response
    }
}

class ClaudeApiClient(apiKey: String) {
    
    private val apiClient = ApiClient("https://api.anthropic.com")
    private val apiKey = apiKey

    suspend fun sendMessage(
        message: String,
        model: String = "claude-3-5-sonnet-20241022",
        maxTokens: Int = 1024
    ): ApiResponse<String> {
        val body = JsonObject().apply {
            addProperty("model", model)
            add("messages", com.google.gson.JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "user")
                    addProperty("content", message)
                })
            })
            addProperty("max_tokens", maxTokens)
        }.toString()

        val headers = mapOf(
            "x-api-key" to apiKey,
            "anthropic-version" to "2023-06-01",
            "content-type" to "application/json"
        )

        return apiClient.post(
            endpoint = "/v1/messages",
            headers = headers,
            body = body
        )
    }

    fun shutdown() {
        apiClient.shutdown()
    }
}

class OpenAIApiClient(apiKey: String) {
    
    private val apiClient = ApiClient("https://api.openai.com")
    private val apiKey = apiKey

    suspend fun sendMessage(
        message: String,
        model: String = "gpt-3.5-turbo",
        maxTokens: Int = 1024
    ): ApiResponse<String> {
        val body = JsonObject().apply {
            addProperty("model", model)
            add("messages", com.google.gson.JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "user")
                    addProperty("content", message)
                })
            })
            addProperty("max_tokens", maxTokens)
            addProperty("temperature", 0.7)
        }.toString()

        val headers = mapOf(
            "Authorization" to "Bearer $apiKey",
            "content-type" to "application/json"
        )

        return apiClient.post(
            endpoint = "/v1/chat/completions",
            headers = headers,
            body = body
        )
    }

    fun shutdown() {
        apiClient.shutdown()
    }
}

/**
 * Generic API request builder for custom API calls
 */
class ApiRequestBuilder {
    private var method: String = "GET"
    private var url: String = ""
    private var headers: MutableMap<String, String> = mutableMapOf()
    private var body: String = ""

    fun method(method: String) = apply { this.method = method }
    fun url(url: String) = apply { this.url = url }
    fun header(key: String, value: String) = apply { headers[key] = value }
    fun headers(map: Map<String, String>) = apply { this.headers.putAll(map) }
    fun body(body: String) = apply { this.body = body }

    fun build(): ApiRequest {
        return ApiRequest(method, url, headers.toMap(), body)
    }
}

data class ApiRequest(
    val method: String,
    val url: String,
    val headers: Map<String, String>,
    val body: String
)

suspend fun ApiRequest.execute(): ApiResponse<String> {
    return try {
        val requestBody = if (body.isNotEmpty()) {
            body.toRequestBody("application/json".toMediaType())
        } else {
            null
        }

        val requestBuilder = Request.Builder()
            .url(url)

        when (method.uppercase()) {
            "GET" -> requestBuilder.get()
            "POST" -> requestBuilder.post(requestBody ?: "".toRequestBody())
            "PUT" -> requestBuilder.put(requestBody ?: "".toRequestBody())
            "DELETE" -> requestBuilder.delete(requestBody)
            "PATCH" -> requestBuilder.patch(requestBody ?: "".toRequestBody())
        }

        headers.forEach { (key, value) ->
            requestBuilder.addHeader(key, value)
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .build()

        val request = requestBuilder.build()
        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        ApiResponse(
            data = responseBody,
            error = if (response.isSuccessful) null else response.message,
            statusCode = response.code,
            isSuccess = response.isSuccessful
        )
    } catch (e: Exception) {
        ApiResponse(
            data = null,
            error = e.message,
            statusCode = -1,
            isSuccess = false
        )
    }
}
