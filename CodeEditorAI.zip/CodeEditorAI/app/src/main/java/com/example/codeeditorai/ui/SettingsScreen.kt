package com.example.codeeditorai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.codeeditorai.data.AppSettings

@Composable
fun SettingsScreen(
    currentSettings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2D2D2D))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = Color.White)
            }
            Text(
                "Settings",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        // Settings Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Editor Settings
            item {
                SettingsSection("📝 Editor")
            }

            item {
                SettingSlider(
                    title = "Font Size",
                    value = currentSettings.fontSize.toFloat(),
                    onValueChange = { newSize ->
                        onSettingsChange(
                            currentSettings.copy(fontSize = newSize.toInt())
                        )
                    },
                    range = 8f..24f,
                    unit = "pt"
                )
            }

            item {
                SettingToggle(
                    title = "Line Numbers",
                    value = currentSettings.showLineNumbers,
                    onValueChange = { show ->
                        onSettingsChange(
                            currentSettings.copy(showLineNumbers = show)
                        )
                    }
                )
            }

            item {
                SettingToggle(
                    title = "Word Wrap",
                    value = currentSettings.wordWrap,
                    onValueChange = { wrap ->
                        onSettingsChange(
                            currentSettings.copy(wordWrap = wrap)
                        )
                    }
                )
            }

            // Auto-save Settings
            item {
                SettingsSection("💾 Auto-Save")
            }

            item {
                SettingToggle(
                    title = "Enable Auto-Save",
                    value = currentSettings.autoSave,
                    onValueChange = { enabled ->
                        onSettingsChange(
                            currentSettings.copy(autoSave = enabled)
                        )
                    }
                )
            }

            if (currentSettings.autoSave) {
                item {
                    SettingSlider(
                        title = "Auto-Save Interval",
                        value = currentSettings.autoSaveInterval.toFloat() / 1000,
                        onValueChange = { newInterval ->
                            onSettingsChange(
                                currentSettings.copy(
                                    autoSaveInterval = (newInterval * 1000).toLong()
                                )
                            )
                        },
                        range = 1f..30f,
                        unit = "s"
                    )
                }
            }

            // Theme Settings
            item {
                SettingsSection("🎨 Appearance")
            }

            item {
                SettingDropdown(
                    title = "Theme",
                    options = listOf("Dark", "Light", "Auto"),
                    selectedOption = currentSettings.theme,
                    onOptionSelected = { selected ->
                        onSettingsChange(
                            currentSettings.copy(theme = selected.lowercase())
                        )
                    }
                )
            }

            // Advanced Settings
            item {
                SettingsSection("⚙️ Advanced")
            }

            item {
                SettingDropdown(
                    title = "Default Language",
                    options = listOf("Python", "JavaScript", "Java", "HTML"),
                    selectedOption = currentSettings.defaultLanguage.replaceFirstChar { it.uppercase() },
                    onOptionSelected = { selected ->
                        onSettingsChange(
                            currentSettings.copy(defaultLanguage = selected.lowercase())
                        )
                    }
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF2D2D2D)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "💡 Tips",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "• Use keyboard shortcuts for faster editing\n" +
                            "• Enable auto-save to prevent data loss\n" +
                            "• Adjust font size for better readability\n" +
                            "• Use Termux for advanced terminal commands",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun SettingsSection(title: String) {
    Text(
        title,
        color = Color(0xFF667eea),
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun SettingToggle(
    title: String,
    value: Boolean,
    onValueChange: (Boolean) -> Unit,
    icon: String = "⚙️"
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D2D2D)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "$icon $title",
                color = Color.White,
                fontSize = 12.sp
            )

            Switch(
                checked = value,
                onCheckedChange = onValueChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF667eea),
                    checkedTrackColor = Color(0xFF667eea).copy(alpha = 0.5f)
                )
            )
        }
    }
}

@Composable
fun SettingSlider(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    unit: String = ""
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D2D2D)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 12.sp
                )
                Text(
                    "${value.toInt()}$unit",
                    color = Color(0xFF667eea),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = range,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF667eea),
                    activeTrackColor = Color(0xFF667eea),
                    inactiveTrackColor = Color(0xFF3D3D3D)
                )
            )
        }
    }
}

@Composable
fun SettingDropdown(
    title: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D2D2D)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 12.sp
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        selectedOption,
                        color = Color(0xFF667eea),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        Icons.Default.ExpandMore,
                        null,
                        tint = Color(0xFF667eea),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E1E))
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                option,
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        },
                        onClick = {
                            onOptionSelected(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PreferencesButton(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(Icons.Default.Settings, "Settings", tint = Color.White)
    }
}
