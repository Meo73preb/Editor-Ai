package com.example.codeeditorai.web

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import kotlin.concurrent.thread

class WebServerService(private val context: Context) {
    private var serverSocket: ServerSocket? = null
    private val PORT = 2435
    private var isRunning = false

    fun start(): Boolean {
        return try {
            serverSocket = ServerSocket(PORT)
            isRunning = true
            
            thread(daemon = true) {
                while (isRunning && serverSocket != null) {
                    try {
                        val socket = serverSocket?.accept() ?: break
                        handleRequest(socket)
                    } catch (e: Exception) {
                        if (isRunning) {
                            Log.e("WebServer", "Error accepting connection: ${e.message}")
                        }
                    }
                }
            }
            
            Log.d("WebServer", "Server started on port $PORT")
            true
        } catch (e: Exception) {
            Log.e("WebServer", "Failed to start server: ${e.message}")
            false
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Log.e("WebServer", "Error stopping server: ${e.message}")
        }
    }

    private fun handleRequest(socket: Socket) {
        thread {
            try {
                val input = InputStreamReader(socket.inputStream)
                val requestLine = input.readLine() ?: return@thread
                
                val parts = requestLine.split(" ")
                if (parts.size < 2) {
                    sendResponse(socket, 400, "Bad Request")
                    return@thread
                }

                val method = parts[0]
                val path = URLDecoder.decode(parts[1], StandardCharsets.UTF_8.name())

                when (method) {
                    "GET" -> handleGET(socket, path)
                    "POST" -> handlePOST(socket, path)
                    else -> sendResponse(socket, 405, "Method Not Allowed")
                }
            } catch (e: Exception) {
                Log.e("WebServer", "Error handling request: ${e.message}")
            } finally {
                try {
                    socket.close()
                } catch (e: Exception) {
                    Log.e("WebServer", "Error closing socket: ${e.message}")
                }
            }
        }
    }

    private fun handleGET(socket: Socket, path: String) {
        when {
            path == "/" -> {
                val content = getIndexPage()
                sendResponse(socket, 200, content, "text/html")
            }
            path.endsWith(".js") && path.contains("eruda") -> {
                // Load eruda from CDN
                val erudaURL = "https://cdn.jsdelivr.net/npm/eruda"
                sendResponse(socket, 200, "<!-- Eruda Debug Tools -->", "text/javascript")
            }
            path.endsWith(".html") -> {
                val file = File(path.removePrefix("/"))
                if (file.exists()) {
                    sendResponse(socket, 200, file.readText(), "text/html")
                } else {
                    sendResponse(socket, 404, "File not found")
                }
            }
            path.endsWith(".css") -> {
                val file = File(path.removePrefix("/"))
                if (file.exists()) {
                    sendResponse(socket, 200, file.readText(), "text/css")
                } else {
                    sendResponse(socket, 404, "File not found")
                }
            }
            path.endsWith(".js") -> {
                val file = File(path.removePrefix("/"))
                if (file.exists()) {
                    sendResponse(socket, 200, file.readText(), "application/javascript")
                } else {
                    sendResponse(socket, 404, "File not found")
                }
            }
            else -> {
                sendResponse(socket, 404, "Not found")
            }
        }
    }

    private fun handlePOST(socket: Socket, path: String) {
        when (path) {
            "/api/preview" -> {
                sendResponse(socket, 200, """{"status":"ok"}""", "application/json")
            }
            else -> sendResponse(socket, 404, "Not found")
        }
    }

    private fun sendResponse(
        socket: Socket,
        statusCode: Int,
        body: String,
        contentType: String = "text/html"
    ) {
        try {
            val statusText = when (statusCode) {
                200 -> "OK"
                400 -> "Bad Request"
                404 -> "Not Found"
                405 -> "Method Not Allowed"
                else -> "Unknown"
            }

            val response = """
                HTTP/1.1 $statusCode $statusText
                Content-Type: $contentType; charset=UTF-8
                Content-Length: ${body.toByteArray().size}
                Access-Control-Allow-Origin: *
                Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
                Access-Control-Allow-Headers: Content-Type, Authorization
                Connection: close
                
                $body
            """.trimIndent()

            socket.outputStream.write(response.toByteArray(StandardCharsets.UTF_8))
            socket.outputStream.flush()
        } catch (e: Exception) {
            Log.e("WebServer", "Error sending response: ${e.message}")
        }
    }

    private fun getIndexPage(): String {
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Code Editor AI - HTML Preview</title>
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
                    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
                    .header h1 { font-size: 24px; margin-bottom: 10px; }
                    .info { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
                    .info p { margin: 10px 0; line-height: 1.6; color: #333; }
                    .code-block { background: #f8f9fa; padding: 10px; border-left: 4px solid #667eea; margin: 10px 0; font-family: monospace; overflow-x: auto; }
                    .highlight { color: #667eea; font-weight: bold; }
                    footer { margin-top: 40px; text-align: center; color: #666; font-size: 14px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🎨 HTML Preview Server</h1>
                        <p>Running on localhost:2435</p>
                    </div>
                    
                    <div class="info">
                        <h2>Welcome to Code Editor AI</h2>
                        <p>Your HTML files will be previewed here.</p>
                        
                        <h3 style="margin-top: 20px; color: #667eea;">How to use:</h3>
                        <p>1️⃣ Edit your HTML file in the Code Editor</p>
                        <p>2️⃣ Click the "Preview" button or "Run in Terminal"</p>
                        <p>3️⃣ Your preview will load in this tab</p>
                        
                        <h3 style="margin-top: 20px; color: #667eea;">Server Info:</h3>
                        <div class="code-block">
                            Server: http://localhost:2435
                            Port: 2435
                            Status: ✅ Running
                        </div>
                        
                        <h3 style="margin-top: 20px; color: #667eea;">Features:</h3>
                        <p>✅ Live HTML preview</p>
                        <p>✅ Auto-refresh on save</p>
                        <p>✅ Debug tools support</p>
                        <p>✅ CORS enabled</p>
                        
                        <p style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 4px; color: #0066cc;">
                            <strong>💡 Tip:</strong> Open browser DevTools (F12) for debugging
                        </p>
                    </div>
                    
                    <footer>
                        <p>Code Editor AI © 2024 | Powered by Kotlin & Jetpack Compose</p>
                    </footer>
                </div>
                
                <script>
                    // Auto-refresh functionality
                    setInterval(() => {
                        console.log('Server is running...');
                    }, 5000);
                </script>
            </body>
            </html>
        """.trimIndent()
    }

    fun isRunning(): Boolean = isRunning
}
