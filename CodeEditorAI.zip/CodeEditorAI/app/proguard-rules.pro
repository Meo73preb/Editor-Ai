# Anthropic API
-keep class com.anthropic.** { *; }
-dontwarn com.anthropic.**

# OkHttp
-keepattributes Signature
-keepattributes *Annotation*
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**

# Gson
-keep class sun.misc.Unsafe { *; }
-keep class com.google.gson.** { *; }
-dontwarn com.google.gson.**

# Termux
-keep class com.termux.** { *; }
-dontwarn com.termux.**

# Kotlin
-keep class kotlin.** { *; }
-dontwarn kotlin.**

# Coroutines
-keepclassmembernames class kotlinx.coroutines.internal.MainDispatcherFactory {
    *** getInstance(...);
}

# Keep all model classes
-keep class com.example.codeeditorai.data.** { *; }
-keep class com.example.codeeditorai.ui.** { *; }

# Keep service classes
-keep class com.example.codeeditorai.terminal.** { *; }
-keep class com.example.codeeditorai.file.** { *; }
-keep class com.example.codeeditorai.ai.** { *; }
-keep class com.example.codeeditorai.web.** { *; }

# Remove logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
