# 🎯 Code Editor AI - Mobile IDE with AI Integration

A powerful Android code editor with integrated terminal, AI code suggestions, and HTML preview - all in one app!

## ✨ Features

### 📝 **Code Editor**
- Syntax highlighting for multiple languages
- File browser and management
- Auto-save functionality
- Line numbers and word wrap
- Multiple file support

### 💻 **Integrated Terminal**
- Execute bash commands
- Run Python, JavaScript, Java code
- File operations directly in terminal
- Command history
- Real-time output display

### 🤖 **AI Code Assistant**
- **With API Token**: Claude API integration for intelligent suggestions
- **Without Token**: Smart offline suggestions based on code patterns
- Code completion and improvements
- Bug detection and fixes
- Usage examples and explanations

### 🌐 **HTML Preview**
- Live localhost:2435 preview server
- Auto-refresh on file changes
- Debugging tools (eruda.min.js support)
- Direct browser integration

### 🛠️ **Additional Features**
- Multiple language support (Python, JavaScript, Java, Kotlin, HTML, CSS, Bash, JSON, XML)
- Encrypted token storage (AES-256)
- Settings and theme customization
- File search and organization
- Linux environment via Termux

---

## 🚀 Getting Started

### Prerequisites
- Android Studio 2023.1 or higher
- Android SDK 24 (Android 7.0) or higher
- Kotlin 1.9.10+
- Java 17 or higher

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd CodeEditorAI
```

2. **Open in Android Studio**
```bash
# Open Android Studio and select "Open Project"
# Navigate to CodeEditorAI folder
```

3. **Build the project**
```bash
# Using Android Studio: Build → Make Project
# Or using terminal:
./gradlew build
```

4. **Run on emulator or device**
```bash
./gradlew installDebug
```

---

## 🔑 API Token Setup

### Claude API (Recommended)

1. Get token from [Claude API](https://console.anthropic.com)
2. Open app → AI tab → "Add Claude Token"
3. Paste your API key
4. Token is encrypted and stored locally

### OpenAI API (Optional)

Future support planned. Currently focused on Claude API.

---

## 📚 Usage Guide

### Creating and Editing Code

1. **Create New File**
   - Click "New File" in file explorer
   - Select language (Python, JavaScript, etc.)
   - Start coding!

2. **Save File**
   - Use top toolbar "Save" button
   - Files auto-saved every 5 seconds
   - Shows modified indicator (●)

3. **Edit Code**
   - Click file to open in editor
   - Write/modify code
   - Auto-save enabled by default

### Running Code

1. **Python**
```bash
# Click "Run File" button
python3 script.py
```

2. **JavaScript (Node.js)**
```bash
node script.js
```

3. **Java**
```bash
javac Program.java
java Program
```

4. **Bash/Shell**
```bash
bash script.sh
```

5. **HTML**
```bash
# Open HTML Preview tab
# Access via http://localhost:2435
```

### Using AI Assistant

**With Token:**
1. Go to AI tab
2. Write code in editor
3. Click "Get AI Suggestion"
4. View suggestion, explanation, and examples
5. Copy code with "Copy" button

**Without Token (Offline Mode):**
1. Smart suggestions based on code patterns
2. Best practices recommendations
3. Common improvements suggestions
4. Prompts to add token for AI features

---

## 🏗️ Project Structure

```
CodeEditorAI/
├── app/src/main/
│   ├── java/com/example/codeeditorai/
│   │   ├── MainActivity.kt
│   │   ├── data/
│   │   │   ├── Models.kt
│   │   │   └── Repository.kt
│   │   ├── ui/
│   │   │   ├── MainViewModel.kt
│   │   │   └── MainScreen.kt
│   │   ├── ai/
│   │   │   └── AIService.kt
│   │   ├── terminal/
│   │   │   └── TerminalService.kt
│   │   ├── file/
│   │   │   └── FileManager.kt
│   │   └── web/
│   │       └── WebServerService.kt
│   ├── res/
│   │   ├── values/
│   │   │   ├── strings.xml
│   │   │   └── themes.xml
│   │   └── ...
│   └── AndroidManifest.xml
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

---

## 🔧 Technology Stack

### Frontend
- **Jetpack Compose** - Modern UI toolkit
- **Material Design 3** - UI components
- **Kotlin** - Primary language
- **AndroidX** - Android libraries

### Backend & Services
- **Termux Libraries** - Terminal integration
- **OkHttp** - Network requests
- **Gson** - JSON parsing
- **EncryptedSharedPreferences** - Secure storage
- **Coroutines** - Async operations

### AI & APIs
- **Anthropic Claude API** - AI suggestions
- **Custom Web Server** - HTML preview (localhost:2435)

---

## 📝 File Organization

### Document Root: `/Documents/CodeEditorAI/`
- All user files stored here
- Organized by project
- Temp files in `.temp` subfolder

### Termux Integration
- Uses Termux environment for commands
- Python, Node.js, Java available
- Package manager support (apt, pip, npm)

---

## 🛡️ Security

- ✅ Encrypted token storage (AES-256-GCM)
- ✅ No token logging
- ✅ Local processing when possible
- ✅ HTTPS for API calls
- ✅ No sensitive data in logs (release builds)

---

## ⚙️ Settings

### Available Options
- **Theme**: Dark (default)
- **Font Size**: 8-24 pt
- **Auto-save**: On/Off
- **Auto-save Interval**: 1-10 seconds
- **Line Numbers**: On/Off
- **Word Wrap**: On/Off
- **Default Language**: Choose default

---

## 🐛 Troubleshooting

### "Python not installed"
```bash
# Open Termux and run:
apt-get update
apt-get install python3
```

### "Node not found"
```bash
# In Termux:
apt-get install nodejs
```

### Token not working
1. Verify token is valid in Claude dashboard
2. Check internet connection
3. Remove and re-add token
4. Clear app cache: Settings → Apps → Code Editor AI → Storage → Clear Cache

### HTML Preview not loading
1. Check localhost:2435 is accessible
2. Restart app (closes and reopens web server)
3. Check Android version (API 24+)

---

## 📊 Performance Tips

1. **Close unused files** - Reduces memory usage
2. **Use offline mode** - Faster suggestions without API calls
3. **Clear terminal history** - Improves UI responsiveness
4. **Limit file size** - Very large files may slow editing
5. **Enable auto-save** - Prevents accidental data loss

---

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- [ ] More language syntax highlighting
- [ ] Git integration
- [ ] Code formatter
- [ ] Debugger support
- [ ] Extension system
- [ ] Cloud sync

---

## 📄 License

GPL-3.0 License - See LICENSE file

---

## 🎓 Learning Resources

- [Jetpack Compose Docs](https://developer.android.com/jetpack/compose)
- [Anthropic API Docs](https://docs.anthropic.com)
- [Kotlin Documentation](https://kotlinlang.org/docs)
- [Android Developer Guide](https://developer.android.com)

---

## 💬 Support

- Report bugs: Create issue on GitHub
- Feature requests: GitHub discussions
- Email: support@example.com

---

## 🚀 Roadmap

### Version 1.0 (Current)
- ✅ Basic editor with syntax highlighting
- ✅ Terminal integration
- ✅ AI code suggestions
- ✅ HTML preview

### Version 1.1 (Planned)
- [ ] Code formatter (Prettier, Black)
- [ ] Git integration
- [ ] Multiple tabs
- [ ] Themes customization

### Version 2.0 (Future)
- [ ] Debugger support
- [ ] Extensions system
- [ ] Cloud synchronization
- [ ] Collaborative editing

---

## 📱 System Requirements

**Minimum:**
- Android 7.0 (API 24)
- 2GB RAM
- 50MB storage

**Recommended:**
- Android 12+ (API 31+)
- 4GB+ RAM
- 200MB storage

---

Made with ❤️ for developers

Happy Coding! 🚀
