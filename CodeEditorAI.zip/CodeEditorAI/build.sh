#!/bin/bash

# Code Editor AI - Build & Sign APK Script
# This script builds and signs the APK for release

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KEYSTORE_FILE="$PROJECT_DIR/keystore/release.keystore"
KEYSTORE_PASS="CodeEditorAI2026"
KEY_ALIAS="release"
KEY_PASS="CodeEditorAI2026"

echo "================================"
echo "Code Editor AI - Build Script"
echo "================================"
echo ""

# Check if keystore exists
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo "❌ Keystore not found at: $KEYSTORE_FILE"
    echo "Creating keystore..."
    mkdir -p "$PROJECT_DIR/keystore"
    keytool -genkey -v -keystore "$KEYSTORE_FILE" \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -alias "$KEY_ALIAS" \
        -storepass "$KEYSTORE_PASS" \
        -keypass "$KEY_PASS" \
        -dname "CN=CodeEditor,O=Developer,L=Vietnam,C=VN"
fi

echo "✅ Keystore ready"
echo ""

# Clean previous builds
echo "🧹 Cleaning previous builds..."
cd "$PROJECT_DIR"
./gradlew clean --quiet

# Build debug APK
echo "🔨 Building debug APK..."
./gradlew assembleDebug --quiet

# Build release APK
echo "📦 Building release APK..."
./gradlew assembleRelease --quiet

# Find APK files
DEBUG_APK=$(find "$PROJECT_DIR/app/build/outputs/apk" -name "*debug*.apk" -type f 2>/dev/null | head -n 1)
RELEASE_APK=$(find "$PROJECT_DIR/app/build/outputs/apk" -name "*release*.apk" -type f 2>/dev/null | head -n 1)

echo ""
echo "================================"
echo "Build Complete!"
echo "================================"
echo ""

if [ -f "$DEBUG_APK" ]; then
    echo "✅ Debug APK: $DEBUG_APK"
    echo "   Size: $(du -h "$DEBUG_APK" | cut -f1)"
fi

if [ -f "$RELEASE_APK" ]; then
    echo "✅ Release APK (Signed): $RELEASE_APK"
    echo "   Size: $(du -h "$RELEASE_APK" | cut -f1)"
    
    # Verify signature
    echo ""
    echo "🔍 Verifying signature..."
    jarsigner -verify -verbose -certs "$RELEASE_APK" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "✅ Signature verified successfully!"
    fi
fi

echo ""
echo "📱 To install on device:"
echo "   adb install -r $DEBUG_APK"
echo ""
echo "🚀 To install release build:"
echo "   adb install -r $RELEASE_APK"
